extras Package
==============

:mod:`extras` Package
---------------------

.. automodule:: rdflib.extras
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`cmdlineutils` Module
--------------------------

.. automodule:: rdflib.extras.cmdlineutils
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`describer` Module
-----------------------

.. automodule:: rdflib.extras.describer
    :members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: __dict__,__weakref__

:mod:`infixowl` Module
----------------------

.. automodule:: rdflib.extras.infixowl
    :members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: __dict__,__weakref__
